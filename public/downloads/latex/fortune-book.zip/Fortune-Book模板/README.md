# Azen Notebook-inspired LaTeX template

## Files
- `azen-notebook.sty`: reusable visual style
- `example.tex`: complete example document

## Compile in TeXstudio
1. Put `azen-notebook.sty` and `example.tex` in the same folder.
2. Open `example.tex`.
3. Set the compiler to **XeLaTeX**.
4. Compile twice if you want the table of contents and page references to update.

## Customize
- Cover: edit the five arguments of `\azencover`.
- Main body: use `\chapter`, `\section`, and `\subsection`.
- Boxes: `definitionbox`, `theorembox`, `examplebox`, `notebox`,
  `warningbox`, `resultbox`, and `softbox`.
- Colors and page geometry: edit the definitions near the top of `azen-notebook.sty`.

This is an independently recreated, editable style inspired by the uploaded PDF's
visible layout. It is not the original source file and does not claim pixel-perfect
reproduction of the PDF.
